<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ConsultorEventoController extends Controller
{
    //
}
